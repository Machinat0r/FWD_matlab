%------written by Wending Fu, Apr.2025 in Beijing------------
clear;clc;
global ParentDir OutputDir
ParentDir = 'Z:/Data/MMS/'; 
DownloadDir = 'C:/MMS/';
TempDir = [DownloadDir,'temp/'];mkdir(TempDir);
 
Date = '2015-01-01/2023-01-01';
splitDate = regexp(Date,'/','split');
OutputDir = [ParentDir,'CurlB_Search/',splitDate{1},'To',splitDate{2},'/'];
CaseListPath = [OutputDir, 'errorlog.txt'];
ErrorList = load(CaseListPath);

for i = 1:length(ErrorList)
disp(['૮₍ ˃ ⤙ ˂ ₎ა',repmat('■',1,round(10*i/length(ErrorList))),repmat('□',1,10-round(10*i/length(ErrorList))),'正在光速检索ing...'])
fprintf(['当前处理时间为:',num2str(ErrorList(i)),'\n'])

Time1 = ErrorList(i)+1;
Time2 = ErrorList(i)+2;

Time1 = datetime(num2str(Time1), 'InputFormat', 'yyyyMMddHHmmss');
Time2 = datetime(num2str(Time2), 'InputFormat', 'yyyyMMddHHmmss');

TT = [datestr(Time1, 'yyyy-mm-ddTHH:MM:SS.000Z'), '/',...
    datestr(Time2, 'yyyy-mm-ddTHH:MM:SS.000Z')];

tint=irf.tint(TT);
Datelist = regexp(TT,'\d+-\d+-\d+','match');
Datelist{2} = datestr(datenum(Datelist{2},'yyyy-mm-dd')+1,'yyyy-mm-dd');
Date = [Datelist{1},'/',Datelist{2}];
ic = 1;
iic = 1:4;
filenames1 = SDCFilenames(Date,iic,'inst','fgm','drm','brst');
% filenames2 = SDCFilenames(Date,ic,'inst','fpi','drm','brst','dpt','des-moms,dis-moms,des-dist,dis-dist');
% filenames3 = SDCFilenames(Date,ic,'inst','scm','drm','brst','dpt','scb');
% filenames4 = SDCFilenames(Date,ic,'inst','edp','drm','brst','dpt','dce');
% filenames_srvy = SDCFilenames(Date,iic,'inst','fgm','drm','srvy'); 
% filenames_fast = SDCFilenames(Date,ic,'inst','fpi','drm','fast','dpt','des-moms');
filenames = [filenames1];
% % % 
[filenames,~,~] = findFilenames(TT,filenames,'brst',ic);
for ii = 1:length(filenames)
[~,filepath]=isDataInDisk(filenames{ii}, ParentDir);
delete(filepath)
end

try
SDCFilesDownload_NAS(filenames,TempDir, 'Threads', 32, 'CheckSize', 0)
% SDCFilesDownload_NAS(filenames_srvy,TempDir, 'Threads', 64, 'CheckSize', 0)
SDCDataMove(TempDir,ParentDir)
fileID = fopen(CaseListPath, 'r');
lines = textscan(fileID, '%s', 'Delimiter', '\n');
fclose(fileID);
lines = lines{1}(2:end);
fileID = fopen(CaseListPath, 'w');
fprintf(fileID, '%s\n', lines{:});
fclose(fileID);
catch
    continue
end
end