% V1=[9.4, 47.2, 111.8]*1e3;
% V2=[-13.4,1.7,10.7]*1e3;
% B1=[1.4,-5.4,10.7]*1e-9;
% B2=[15.7,8.6,69.5]*1e-9;
% V1=[203.1885   61.4137   36.5405]*1e3;
ic = 1;
tint = irf.tint('2017-07-06T17:31:56.000Z/2017-07-06T17:31:58.000Z');
% tint2 = irf.tint('2017-07-06T17:31:59.000Z/2017-07-06T17:31:59.500Z');
ParentDir = 'D:/MMS/'; 
mms.db_init('local_file_db',ParentDir);
%%
c_eval('Ve?_ts = mms.get_data(''Ve_gse_fpi_brst_l2'',tint,?);',ic)
c_eval(['gsmVe?_ts=irf_gse2gsm(Ve?_ts);'],ic);
c_eval(['Ve?=irf.ts2mat(gsmVe?_ts);'],ic);
c_eval(['B?_ts=mms.get_data(''B_gsm_brst'',tint,?);'],ic);
c_eval(['Bt?_ts=B?_ts.abs;'],ic); 
c_eval(['B?=irf.ts2mat(B?_ts);'],ic);
c_eval('Ne?_ts = mms.get_data(''Ne_fpi_brst_l2'',tint,?);',ic);
c_eval(['Ne?=irf.ts2mat(Ne?_ts);'],ic);

c_eval('Ve?_ts2 = mms.get_data(''Ve_gse_fpi_brst_l2'',tint2,?);',ic)
c_eval(['gsmVe?_ts2=irf_gse2gsm(Ve?_ts2);'],ic);
c_eval(['Ve?2=irf.ts2mat(gsmVe?_ts2);'],ic);
c_eval(['B?_ts2=mms.get_data(''B_gsm_brst'',tint2,?);'],ic);
c_eval(['Bt?_ts2=B?_ts2.abs;'],ic); 
c_eval(['B?2=irf.ts2mat(B?_ts2);'],ic);

% dspan = 3;
% c_eval('Ve? = smoothdata(Ve?,''movmean'',dspan);',ic);
% c_eval('B? = smoothdata(B?,''movmean'',dspan);',ic);
c_eval('V1 = mean(Ve?(:,2:4),1)*1e3;',ic);
% c_eval('V2 = mean(Ve?2(:,2:4),1)*1e3;',ic);
V1 = [264.83	32.03	19.02]*1e3;
V2=[521.57 -171.82  -72.48]*1e3;
% B1=[0.6098   -1.5422    4.8874]*1e-9;
B1=[0.62   -1.51    4.78]*1e-9;
% c_eval('B1 = mean(B?(:,2:4),1)*1e-9;',ic);
% c_eval('B2 = mean(B?2(:,2:4),1)*1e-9;',ic);
B2=[2.32   -1.13    9.22]*1e-9;

units=irf_units;
mp=units.me;
% n1=15*1e6;
% n2=2*1e6;
n1=0.24*1e6;
n2=0.14*1e6;
%%
rho1=n1*mp;
rho2=n2*mp;
rho_mean = rho1*rho2/(rho1+rho2);
% Va1 = 22*B1*1e9/sqrt(n1/1e6)*1e3;
% Va2 = 22*B2*1e9/sqrt(n2/1e6)*1e3;

k0 = irf_cross(B1,B2);
% k = k0./norm(k0)
k=(V1-V2)./norm(V1-V2);
% k = [-0.64 0.73 -0.23];
% k = [0.61 0.67 -0.43];
% k=(V1-V2);
% k=[0,0,1]

Va = (norm(B1)^2+norm(B2)^2)/4/pi/rho_mean
left=dot(k,(V1-V2))^2
right=(dot(k,B1)^2+dot(k,B2)^2)/rho_mean/units.mu0
% right=(dot(k,B1)^2+dot(k,B2)^2)/units.me/4/pi
gamma = sqrt(left-right)