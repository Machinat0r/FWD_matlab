%------written by Wending Fu, July.2025 in Singapore------------
clear;clc;
global ParentDir OutputDir
ParentDir = 'Z:\SPART-WORK\Data\MMS\'; 
DownloadDir = 'C:\MMS/';
TempDir = [DownloadDir,'temp/'];mkdir(TempDir);

Date = '2018-07-09/2020-01-01';
splitDate = regexp(Date,'/','split');
ic = 1:4;iic = 1:4;
filenames1 = SDCFilenames(Date,iic,'inst','fgm','drm','brst');
filenames2 = SDCFilenames(Date,iic,'inst','fpi','drm','brst','dpt','des-moms');
filenames3 = SDCFilenames(Date,ic,'inst','scm','drm','brst','dpt','scb');
filenames4 = SDCFilenames(Date,ic,'inst','edp','drm','brst','dpt','dce');
% filenames_srvy = SDCFilenames(Date,ic,'inst','fgm','drm','srvy'); %为了知道坐标
filenames = [filenames1,filenames2, filenames3, filenames4];
% filenames = filenames1;

expr = '_[0-9]+\_v';
NameTags = regexp(filenames,expr,'match');
NameTags = unique(cellfun(@cellstr,NameTags));
FileGroups = cell(1,length(NameTags)); 
for j = 1:length(NameTags)
    FileGroups{j} = filenames(contains(filenames,NameTags{j}));
end
FileGroups = cellfun(@cellstr,FileGroups,'UniformOutput',false);%按时间分类整理后的文件名组

%修改文件夹时特别注意SDCFilesDownload需要datamove的文件夹必须是ParentDir，否则需要手动修改
OutputDir = [DownloadDir,'ESWSearch/',splitDate{1},'To',splitDate{2},'/'];
if ~isfolder([OutputDir,'OverviewFig/'])
    mkdir([OutputDir,'OverviewFig/']);
end

units = irf_units;
%%
for TDT = 1:length(NameTags)-1 %This is a distinctive temp  (๑ˉ∀ˉ๑)
tempDir = [OutputDir,NameTags{TDT}(2:end-2),'/'];
clc;fprintf(['当前处理时间为:',NameTags{TDT}(2:end-2),'\n'])
% SDCFilesDownload_NAS(FileGroups{TDT},TempDir, 'Threads', 64, 'CheckSize', 0)
% SDCDataMove(TempDir,ParentDir)

formatDate = @(s) [s(2:5), '-', s(6:7), '-', s(8:9), 'T', s(10:11), ':', s(12:13), ':', s(14:15), '.000Z'];
tempDate = [formatDate(NameTags{TDT}), '/', formatDate(NameTags{TDT+1})];
% tempDate = [char(NameTags(TDT)) '/' char(NameTags(TDT+1))];
tempTint=irf.tint(tempDate);

mms.db_init('local_file_db',ParentDir);
try
    B1_ts=mms.get_data('B_gsm_brst',tempTint,1);%先导入一个文件看看文件中包含的时间段
    tint = irf.tint(B1_ts.time.epoch(1),B1_ts.time.epoch(end));    
    Pos = mms.get_data('R_gsm',tint,1);
    Pos = Pos.data;
    if isempty(Pos)
    writematrix([NameTags{TDT}(2:end-2),'无位置数据'],[OutputDir,'errorlog.txt'],'WriteMode','append','Encoding','UTF-8')
    continue
    end
catch
    writematrix([NameTags{TDT}(2:end-2),'的数据导入出现问题'],[OutputDir,'errorlog.txt'],'WriteMode','append','Encoding','UTF-8')
    continue
end

%% lobe location
flag = 0;
% if Pos(1,4) >= 2*units.RE/1e3 % |R|>2
try
    c_eval(['E?_ts=mms.get_data(''E_gse_edp_brst_l2'',tint,?);'],ic); 
    c_eval('E? = irf.ts2mat(E?_ts);',ic);
   
    c_eval('Et? = irf_abs(E?);',ic);
    c_eval('id_E? = find(Et?(:,5) >= 10);',ic);
    same_id= intersect(intersect(intersect(id_E1, id_E2), id_E3), id_E4);

    if isempty(same_id)
        writematrix([NameTags{TDT}(2:end-2),'无事件'],[OutputDir,'log.txt'],...
        'WriteMode','append','Encoding','UTF-8')
        continue

    else
        tint = irf_time(E1(same_id(1),1),'epoch>epochTT') + [-2,2];
        % load B
        c_eval(['B?_ts=mms.get_data(''B_gsm_brst'',tint,?);'],ic);
        % c_eval(['Bt?_ts=B?_ts.abs;'],ic); 
        c_eval(['B?=irf.ts2mat(B?_ts);'],ic);
        %  c_eval(['B?_gsm=irf_gse2gsm(B?,-1);'],ic);

        % load R
        tintlong = tint+[-60 60];
        R  = mms.get_data('R_gsm',tint);
        c_eval('Rxyz? = irf.ts_vec_xyz(R.time,R.gsmR?(:,1:3));',ic);

        c_eval(['E?_ts=mms.get_data(''E_gse_edp_brst_l2'',tint,?);'],ic); 
        c_eval(['E?_ts = irf_gse2gsm(E?_ts);'],ic);

        Pfrange = [2 500];
        [Vpx,~, ~, waveEx, ~, Frex, ~, ~, ~, ~,~,~,~] = WaveAna_4SC_fast('E?_ts.x','Rxyz?','B?_ts',tint,'numf',400,...
            'wwidth',1,'frange',Pfrange,'cav',1);  
        specEx=struct('t',waveEx(:,1));
        specEx.f=Frex;
        specEx.p=waveEx(:,2:end);
        specEx.f_label='';
        specEx.p_label={'log_{10} B_{z}^2 (nT^2 Hz^-1)'};         
        specVx=struct('t',Vpx(:,1));
        specVx.f=Frex;
        specVx.p=Vpx(:,2:end);
        specVx.f_label='';
        specVx.p_label={'V_px (km/s)'};

        [Vpy,~, ~, waveEy, ~, Frey, ~, ~, ~, ~,~,~,~] = WaveAna_4SC_fast('E?_ts.y','Rxyz?','B?_ts',tint,'numf',400,...
            'wwidth',1,'frange',Pfrange,'cav',1);  
        specEy=struct('t',waveEy(:,1));
        specEy.f=Frey;
        specEy.p=waveEy(:,2:end);
        specEy.f_label='';
        specEy.p_label={'log_{10} B_{z}^2 (nT^2 Hz^-1)'};         
        specVy=struct('t',Vpy(:,1));
        specVy.f=Frey;
        specVy.p=Vpy(:,2:end);
        specVy.f_label='';
        specVy.p_label={'V_py (km/s)'};

        [Vpz,~, ~, waveEz, ~, Frez, ~, ~, ~, ~,~,~,~] = WaveAna_4SC_fast('E?_ts.z','Rxyz?','B?_ts',tint,'numf',400,...
            'wwidth',1,'frange',Pfrange,'cav',1);  
        specEz=struct('t',waveEz(:,1));
        specEz.f=Frez;
        specEz.p=waveEz(:,2:end);
        specEz.f_label='';
        specEz.p_label={'log_{10} B_{z}^2 (nT^2 Hz^-1)'};         
        specVz=struct('t',Vpz(:,1));
        specVz.f=Frez;
        specVz.p=Vpz(:,2:end);
        specVz.f_label='';
        specVz.p_label={'V_pz (km/s)'};

%%
      % % % close all;
      % % %   h=irf_plot(6,'newfigure');
      % % %   xSize=700; ySize=800;
      % % %   set(0,'DefaultAxesFontSize',8);
      % % %   set(0,'DefaultLineLineWidth',2);
      % % %   set(gcf,'Position',[10 10 xSize ySize]);
      % % %   i_subplot=6;
      % % % 
      % % %   for ii=1:i_subplot-1
      % % %       pospanel(ii,:)=get(h(ii),'pos');
      % % %   end
      % % %   for ii=1:i_subplot-2
      % % %       pospanel(ii,2)=pospanel(ii,2)+(i_subplot-1-ii)*0.005;
      % % %       set(h(ii),'pos',pospanel(ii,:));
      % % %   end              
      % % % 
      % % %   h(1)=irf_panel('Ex');
      % % %   irf_spectrogram(h(1),specEx,'log');
      % % %   hold(h(1),'on');
      % % %   hold(h(1),'off');
      % % %   % caxis(h(1),[-4 -1]);
      % % %   set(h(1),'yscale','log');
      % % %   set(h(1),'Ylim',Pfrange);
      % % %   % set(h(1),'ytick', [ 0.02 0.1 1 4 ]);
      % % %   grid(h(1),'off');
      % % %   ylabel(h(1),{'f (Hz)'},'fontsize',9,'Interpreter','tex');
      % % %   irf_legend(h(1),'(a)',[0.02 0.95],'color','k','fontsize',10)
      % % %   set(h(1),'FontSize',10); 
      % % %   colormap(h(1), jet);
      % % % 
      % % %   h(2)=irf_panel('Vpx');
      % % %   irf_spectrogram(h(2),specVx,'lin');
      % % %   hold(h(2),'on');
      % % %   hold(h(2),'off');
      % % %   caxis(h(2),[3e4 5e5]);
      % % %   set(h(2),'yscale','log');
      % % %   set(h(2),'Ylim',Pfrange)
      % % %   grid(h(2),'off');
      % % %   ylabel(h(2),{'f (Hz)'},'fontsize',9,'Interpreter','tex');
      % % %   irf_legend(h(2),'(b)',[0.02 0.95],'color','k','fontsize',10)
      % % %   % set(h(2),'ytick', [ 0.02 0.1 1 4 ]);
      % % %   set(h(2),'FontSize',10);        
      % % %   colormap(h(2), jet);
      % % % 
      % % %   h(3)=irf_panel('Ey');
      % % %   irf_spectrogram(h(3),specEy,'log');
      % % %   hold(h(3),'on');
      % % %   hold(h(3),'off');
      % % %   % caxis(h(1),[-4 -1]);
      % % %   set(h(3),'yscale','log');
      % % %   set(h(3),'Ylim',Pfrange);
      % % %   % set(h(1),'ytick', [ 0.02 0.1 1 4 ]);
      % % %   grid(h(3),'off');
      % % %   ylabel(h(3),{'f (Hz)'},'fontsize',9,'Interpreter','tex');
      % % %   irf_legend(h(3),'(c)',[0.02 0.95],'color','k','fontsize',10)
      % % %   set(h(3),'FontSize',10); 
      % % %   colormap(h(3), jet);
      % % % 
      % % %   h(4)=irf_panel('Vpy');
      % % %   irf_spectrogram(h(4),specVy,'lin');
      % % %   hold(h(4),'on');
      % % %   hold(h(4),'off');
      % % %   caxis(h(4),[3e4 5e5]);
      % % %   set(h(4),'yscale','log');
      % % %   set(h(4),'Ylim',Pfrange)
      % % %   grid(h(4),'off');
      % % %   ylabel(h(4),{'f (Hz)'},'fontsize',9,'Interpreter','tex');
      % % %   irf_legend(h(4),'(d)',[0.02 0.95],'color','k','fontsize',10)
      % % %   % set(h(2),'ytick', [ 0.02 0.1 1 4 ]);
      % % %   set(h(4),'FontSize',10);        
      % % %   colormap(h(4), jet);
      % % % 
      % % %   h(5)=irf_panel('Ez');
      % % %   irf_spectrogram(h(5),specEz,'log');
      % % %   hold(h(5),'on');
      % % %   hold(h(5),'off');
      % % %   % caxis(h(1),[-4 -1]);
      % % %   set(h(5),'yscale','log');
      % % %   set(h(5),'Ylim',Pfrange);
      % % %   % set(h(5),'ytick', [ 0.02 0.1 1 4 ]);
      % % %   grid(h(5),'off');
      % % %   ylabel(h(5),{'f (Hz)'},'fontsize',9,'Interpreter','tex');
      % % %   irf_legend(h(5),'(e)',[0.02 0.95],'color','k','fontsize',10)
      % % %   set(h(5),'FontSize',10); 
      % % %   colormap(h(5), jet);
      % % % 
      % % %   h(6)=irf_panel('Vpz');
      % % %   irf_spectrogram(h(6),specVz,'lin');
      % % %   hold(h(6),'on');
      % % %   hold(h(6),'off');
      % % %   caxis(h(6),[3e4 5e5]);
      % % %   set(h(6),'yscale','log');
      % % %   set(h(6),'Ylim',Pfrange)
      % % %   grid(h(6),'off');
      % % %   ylabel(h(6),{'f (Hz)'},'fontsize',9,'Interpreter','tex');
      % % %   irf_legend(h(6),'(f)',[0.02 0.95],'color','k','fontsize',10)
      % % %   % set(h(2),'ytick', [ 0.02 0.1 1 4 ]);
      % % %   set(h(6),'FontSize',10);        
      % % %   colormap(h(6), jet);

%%
% % % irf_zoom(tint,'x',h(1:i_subplot));
% % % irf_plot_axis_align(i_subplot)

%%  出图保存部分
% % % set(gca,"XTickLabelRotation",0)
% % % % set(gcf,'render','painters');
% % % % set(gcf,'paperpositionmode','auto')
% % % % figname = [OutputDir,'OverviewFig\',Name(2:end-2)];   
% % % mkdir([OutputDir,'DRAFT\']);
% % % tempName = strrep(irf_time(E1(same_id(1),1),'epoch>utc'),':','');tempName = strrep(tempName,'.','');
% % % figname = [OutputDir,'DRAFT\', tempName];  
% % % print(gcf, '-dpng', [figname '.png']);    
% % % pause(1)
% % % close all

% save([OutputDir,'DRAFT\', tempName, '.mat'], 'specEx','specVx', 'specEy','specVy', 'specEz','specVz')
writematrix([irf_time(B1(1),'epoch>utc'),'的最大速度为',num2str(max([Vpx(:,2:end), Vpy(:,2:end), Vpz(:,2:end)],[],'all'))],...
    [OutputDir,'DRAFTCaseList.txt'],'WriteMode','append','Encoding','UTF-8')

    end
    
  
catch
    writematrix([NameTags{TDT}(2:end-2),'的数据导入出现问题'],[OutputDir,'errorlog.txt'],...
        'WriteMode','append','Encoding','UTF-8')
    continue
end
% else
%     continue
% end
% % % %% 符合判据的继续下载并出图
% % % if flag == 2
% % % try
% % %     mms.db_init('local_file_db',ParentDir);
% % %     for i_plot = 1:length(flagTime)
% % %     PlotTint = irf_time([flagTime(i_plot)-0.4,flagTime(i_plot)+0.4],'epoch>epochTT');
% % %     ESWPlot(PlotTint,ic,[NameTags{TDT}(2:end-1),num2str(i_plot)]);
% % %     end
% % % catch
% % %     writematrix([irf_time(flagTime(end),'epoch>utc'),'的画图出现问题'],[OutputDir,'errorlog.txt'],...
% % %     'WriteMode','append','Encoding','UTF-8')
% % %     continue
% % % end
% % % end
%% 删除文件夹并生成记录文件
% % % try
% % %     cd(OutputDir)
% % %     rmdir(tempDir,'s');    
% % % catch
% % %     writematrix(['删除文件夹',NameTags{TDT}(2:end-2),'失败'],[OutputDir,'errorlog.txt'],'WriteMode','append','Encoding','UTF-8')
% % % end
end